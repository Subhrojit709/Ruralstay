"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Home, ArrowLeft, User, MapPin, Calendar, Star, Heart, Settings, Camera, Edit } from "lucide-react"

export default function ClientProfile() {
  const [isEditing, setIsEditing] = useState(false)
  const [profileData, setProfileData] = useState({
    name: "Priya Sharma",
    email: "priya.sharma@email.com",
    phone: "+91 98765 43210",
    location: "Mumbai, Maharashtra",
    bio: "Travel enthusiast who loves exploring rural destinations and experiencing local cultures. Always looking for authentic experiences and meaningful connections with local communities.",
    joinDate: "January 2023",
    totalTrips: 12,
    favoriteDestinations: ["Kerala", "Rajasthan", "Himachal Pradesh"],
  })

  const bookingHistory = [
    {
      id: 1,
      property: "Traditional Kerala Homestay",
      location: "Kerala Backwaters",
      host: "Ravi Kumar",
      dates: "Feb 15-18, 2024",
      status: "completed",
      rating: 5,
      amount: 8800,
      image: "/placeholder.svg?height=100&width=150",
    },
    {
      id: 2,
      property: "Rajasthani Desert Camp",
      location: "Rajasthan Desert",
      host: "Meera Singh",
      dates: "Jan 20-23, 2024",
      status: "completed",
      rating: 4,
      amount: 9000,
      image: "/placeholder.svg?height=100&width=150",
    },
    {
      id: 3,
      property: "Himalayan Mountain Retreat",
      location: "Himachal Hills",
      host: "Suresh Thakur",
      dates: "Dec 10-14, 2023",
      status: "completed",
      rating: 5,
      amount: 10000,
      image: "/placeholder.svg?height=100&width=150",
    },
  ]

  const favoriteProperties = [
    {
      id: 1,
      name: "Goan Village Cottage",
      location: "Goa Villages",
      price: 2200,
      rating: 4.7,
      image: "/placeholder.svg?height=100&width=150",
    },
    {
      id: 2,
      name: "Tamil Nadu Farmhouse",
      location: "Tamil Nadu Countryside",
      price: 1800,
      rating: 4.6,
      image: "/placeholder.svg?height=100&width=150",
    },
  ]

  const handleSaveProfile = () => {
    setIsEditing(false)
    // Save profile data logic here
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <Link href="/client/dashboard" className="flex items-center space-x-2">
              <ArrowLeft className="h-5 w-5 text-green-600" />
              <Home className="h-8 w-8 text-green-600" />
              <h1 className="text-2xl font-bold text-green-800">Rural Tours</h1>
            </Link>
            <div className="flex items-center space-x-4">
              <Button variant="ghost">My Bookings</Button>
              <Button variant="outline">Logout</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Profile Header */}
          <Card className="mb-8">
            <CardContent className="p-8">
              <div className="flex items-start space-x-6">
                <div className="relative">
                  <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center">
                    <User className="h-12 w-12 text-green-600" />
                  </div>
                  <Button
                    size="sm"
                    className="absolute -bottom-2 -right-2 rounded-full p-2 bg-green-600 hover:bg-green-700"
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="text-2xl font-bold text-green-800">{profileData.name}</h2>
                      <p className="text-gray-600 flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {profileData.location}
                      </p>
                    </div>
                    <Button variant="outline" onClick={() => setIsEditing(!isEditing)} className="bg-transparent">
                      <Edit className="h-4 w-4 mr-2" />
                      {isEditing ? "Cancel" : "Edit Profile"}
                    </Button>
                  </div>
                  <p className="text-gray-700 mb-4">{profileData.bio}</p>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-600">{profileData.totalTrips}</p>
                      <p className="text-sm text-gray-600">Total Trips</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-600">{bookingHistory.length}</p>
                      <p className="text-sm text-gray-600">Reviews Given</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-600">
                        {(
                          bookingHistory.reduce((sum, booking) => sum + booking.rating, 0) / bookingHistory.length
                        ).toFixed(1)}
                      </p>
                      <p className="text-sm text-gray-600">Avg Rating Given</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Profile Tabs */}
          <Tabs defaultValue="bookings" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="bookings">Booking History</TabsTrigger>
              <TabsTrigger value="favorites">Favorites</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="bookings">
              <Card>
                <CardHeader>
                  <CardTitle className="text-green-800">Booking History</CardTitle>
                  <CardDescription>Your past and upcoming bookings</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {bookingHistory.map((booking) => (
                      <div key={booking.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Image
                          src={booking.image || "/placeholder.svg"}
                          alt={booking.property}
                          width={150}
                          height={100}
                          className="rounded-lg object-cover"
                        />
                        <div className="flex-1">
                          <h4 className="font-semibold text-green-800">{booking.property}</h4>
                          <p className="text-gray-600 flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {booking.location}
                          </p>
                          <p className="text-sm text-gray-500">Host: {booking.host}</p>
                          <p className="text-sm text-gray-500 flex items-center">
                            <Calendar className="h-4 w-4 mr-1" />
                            {booking.dates}
                          </p>
                        </div>
                        <div className="text-right">
                          <Badge variant={booking.status === "completed" ? "default" : "secondary"} className="mb-2">
                            {booking.status}
                          </Badge>
                          <p className="font-semibold text-green-600">₹{booking.amount.toLocaleString()}</p>
                          <div className="flex items-center mt-1">
                            <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                            <span className="text-sm">{booking.rating}/5</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="favorites">
              <Card>
                <CardHeader>
                  <CardTitle className="text-green-800">Favorite Properties</CardTitle>
                  <CardDescription>Properties you've saved for later</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid md:grid-cols-2 gap-4">
                    {favoriteProperties.map((property) => (
                      <div key={property.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <Image
                          src={property.image || "/placeholder.svg"}
                          alt={property.name}
                          width={150}
                          height={100}
                          className="rounded-lg object-cover"
                        />
                        <div className="flex-1">
                          <h4 className="font-semibold text-green-800">{property.name}</h4>
                          <p className="text-gray-600 flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {property.location}
                          </p>
                          <div className="flex items-center justify-between mt-2">
                            <div className="flex items-center">
                              <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                              <span className="text-sm">{property.rating}</span>
                            </div>
                            <p className="font-semibold text-green-600">₹{property.price}/night</p>
                          </div>
                        </div>
                        <Button size="sm" variant="outline" className="bg-transparent">
                          <Heart className="h-4 w-4 fill-red-500 text-red-500" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="reviews">
              <Card>
                <CardHeader>
                  <CardTitle className="text-green-800">Your Reviews</CardTitle>
                  <CardDescription>Reviews you've written for properties</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {bookingHistory.map((booking) => (
                      <div key={booking.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h4 className="font-semibold text-green-800">{booking.property}</h4>
                          <div className="flex items-center">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`h-4 w-4 ${
                                  i < booking.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                        </div>
                        <p className="text-gray-700 text-sm">
                          "Amazing experience! The host was very welcoming and the property exceeded expectations. Would
                          definitely recommend to anyone looking for an authentic rural experience."
                        </p>
                        <p className="text-xs text-gray-500 mt-2">{booking.dates}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle className="text-green-800">Profile Settings</CardTitle>
                  <CardDescription>Manage your account information and preferences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {isEditing ? (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                        <Input
                          value={profileData.name}
                          onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <Input
                          value={profileData.email}
                          onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                        <Input
                          value={profileData.phone}
                          onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                        <Input
                          value={profileData.location}
                          onChange={(e) => setProfileData({ ...profileData, location: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                        <textarea
                          className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                          rows={4}
                          value={profileData.bio}
                          onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                        />
                      </div>
                      <div className="flex space-x-3">
                        <Button className="bg-green-600 hover:bg-green-700" onClick={handleSaveProfile}>
                          Save Changes
                        </Button>
                        <Button variant="outline" onClick={() => setIsEditing(false)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                          <p className="text-gray-900">{profileData.email}</p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                          <p className="text-gray-900">{profileData.phone}</p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Member Since</label>
                          <p className="text-gray-900">{profileData.joinDate}</p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                          <p className="text-gray-900">{profileData.location}</p>
                        </div>
                      </div>

                      <div className="pt-4 border-t">
                        <h4 className="font-medium text-gray-900 mb-3">Notification Preferences</h4>
                        <div className="space-y-3">
                          <label className="flex items-center">
                            <input type="checkbox" className="mr-3" defaultChecked />
                            <span className="text-sm">Email notifications for booking confirmations</span>
                          </label>
                          <label className="flex items-center">
                            <input type="checkbox" className="mr-3" defaultChecked />
                            <span className="text-sm">SMS notifications for important updates</span>
                          </label>
                          <label className="flex items-center">
                            <input type="checkbox" className="mr-3" />
                            <span className="text-sm">Marketing emails about new properties</span>
                          </label>
                        </div>
                      </div>

                      <div className="pt-4 border-t">
                        <h4 className="font-medium text-gray-900 mb-3">Account Actions</h4>
                        <div className="space-y-2">
                          <Button variant="outline" className="w-full justify-start bg-transparent">
                            <Settings className="h-4 w-4 mr-2" />
                            Change Password
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start text-red-600 border-red-200 hover:bg-red-50 bg-transparent"
                          >
                            Delete Account
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
