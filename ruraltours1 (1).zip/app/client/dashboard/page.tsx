"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Home, Search, MapPin, Users, Star, Heart, Filter } from "lucide-react"

export default function ClientDashboard() {
  const [selectedLocation, setSelectedLocation] = useState("")
  const [searchQuery, setSearchQuery] = useState("")

  const locations = [
    "Goa Villages",
    "Kerala Backwaters",
    "Rajasthan Desert",
    "Himachal Hills",
    "Tamil Nadu Countryside",
    "Karnataka Plantations",
    "Uttarakhand Mountains",
  ]

  const properties = [
    {
      id: 1,
      name: "Traditional Kerala Homestay",
      location: "Kerala Backwaters",
      host: "Ravi Kumar",
      price: "₹2,500/night",
      rating: 4.8,
      reviews: 24,
      bedrooms: 3,
      bathrooms: 2,
      maxGuests: 6,
      features: ["WiFi", "Traditional Kitchen", "Backwater View", "Boat Rides"],
      activities: ["Fishing", "Cooking Classes", "Village Tours", "Ayurveda"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 2,
      name: "Rajasthani Desert Camp",
      location: "Rajasthan Desert",
      host: "Meera Singh",
      price: "₹3,000/night",
      rating: 4.9,
      reviews: 18,
      bedrooms: 2,
      bathrooms: 1,
      maxGuests: 4,
      features: ["Desert View", "Camel Safari", "Bonfire", "Traditional Meals"],
      activities: ["Camel Riding", "Desert Safari", "Folk Dance", "Star Gazing"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 3,
      name: "Himalayan Mountain Retreat",
      location: "Himachal Hills",
      host: "Suresh Thakur",
      price: "₹2,000/night",
      rating: 4.7,
      reviews: 31,
      bedrooms: 4,
      bathrooms: 3,
      maxGuests: 8,
      features: ["Mountain View", "Fireplace", "Organic Garden", "Trekking Gear"],
      activities: ["Trekking", "Apple Picking", "Village Walks", "Photography"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 4,
      name: "Goan Village Cottage",
      location: "Goa Villages",
      host: "Maria Fernandes",
      price: "₹2,200/night",
      rating: 4.6,
      reviews: 15,
      bedrooms: 2,
      bathrooms: 2,
      maxGuests: 4,
      features: ["Beach Access", "Portuguese Architecture", "Garden", "Bicycle"],
      activities: ["Beach Walks", "Spice Tours", "Feni Tasting", "Local Markets"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 5,
      name: "Tamil Nadu Farmhouse",
      location: "Tamil Nadu Countryside",
      host: "Krishnan Pillai",
      price: "₹1,800/night",
      rating: 4.5,
      reviews: 22,
      bedrooms: 3,
      bathrooms: 2,
      maxGuests: 6,
      features: ["Farm Experience", "Organic Food", "Bullock Cart", "Traditional Games"],
      activities: ["Farming", "Pottery Making", "Temple Visits", "Folk Music"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 6,
      name: "Karnataka Coffee Plantation",
      location: "Karnataka Plantations",
      host: "Rajesh Gowda",
      price: "₹2,800/night",
      rating: 4.9,
      reviews: 28,
      bedrooms: 2,
      bathrooms: 2,
      maxGuests: 4,
      features: ["Coffee Tours", "Plantation View", "Bonfire", "Bird Watching"],
      activities: ["Coffee Picking", "Nature Walks", "Waterfall Trek", "Spice Garden"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 7,
      name: "Uttarakhand Mountain Lodge",
      location: "Uttarakhand Mountains",
      host: "Deepak Rawat",
      price: "₹2,300/night",
      rating: 4.8,
      reviews: 19,
      bedrooms: 3,
      bathrooms: 2,
      maxGuests: 6,
      features: ["Valley View", "Yoga Deck", "Organic Kitchen", "Library"],
      activities: ["Yoga Sessions", "Meditation", "River Rafting", "Village Walks"],
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 8,
      name: "Assam Tea Garden Stay",
      location: "Assam Tea Gardens",
      host: "Priyanka Bora",
      price: "₹2,100/night",
      rating: 4.7,
      reviews: 16,
      bedrooms: 2,
      bathrooms: 1,
      maxGuests: 4,
      features: ["Tea Garden View", "Traditional Huts", "Cultural Shows", "Elephant Safari"],
      activities: ["Tea Plucking", "Elephant Rides", "River Cruise", "Tribal Dance"],
      image: "/placeholder.svg?height=200&width=300",
    },
  ]

  const filteredProperties = properties.filter(
    (property) =>
      (!selectedLocation || property.location === selectedLocation) &&
      (!searchQuery ||
        property.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        property.location.toLowerCase().includes(searchQuery.toLowerCase())),
  )

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <Link href="/" className="flex items-center space-x-2">
              <Home className="h-8 w-8 text-green-600" />
              <h1 className="text-2xl font-bold text-green-800">Rural Tours</h1>
            </Link>
            <div className="flex items-center space-x-4">
              <Button variant="ghost">My Bookings</Button>
              <Link href="/client/profile">
                <Button variant="ghost">Profile</Button>
              </Link>
              <Button variant="outline">Logout</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Search and Filter Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-green-800 mb-6">Find Your Perfect Rural Stay</h2>

          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="grid md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Search</label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search properties or locations..."
                    className="pl-10"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                <select
                  className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  value={selectedLocation}
                  onChange={(e) => setSelectedLocation(e.target.value)}
                >
                  <option value="">All Locations</option>
                  {locations.map((location) => (
                    <option key={location} value={location}>
                      {location}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex items-end">
                <Button className="w-full bg-green-600 hover:bg-green-700">
                  <Filter className="h-4 w-4 mr-2" />
                  More Filters
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Properties Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProperties.map((property) => (
            <Card key={property.id} className="overflow-hidden hover:shadow-lg transition-shadow">
              <div className="relative">
                <Image
                  src={property.image || "/placeholder.svg"}
                  alt={property.name}
                  width={300}
                  height={200}
                  className="w-full h-48 object-cover"
                />
                <Button size="sm" variant="secondary" className="absolute top-2 right-2 p-2">
                  <Heart className="h-4 w-4" />
                </Button>
              </div>

              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-lg text-green-800">{property.name}</CardTitle>
                    <CardDescription className="flex items-center mt-1">
                      <MapPin className="h-4 w-4 mr-1" />
                      {property.location}
                    </CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center">
                      <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                      <span className="font-medium">{property.rating}</span>
                      <span className="text-gray-500 text-sm ml-1">({property.reviews})</span>
                    </div>
                  </div>
                </div>
              </CardHeader>

              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-gray-600">
                    <Users className="h-4 w-4 mr-2" />
                    {property.bedrooms} bed • {property.bathrooms} bath • {property.maxGuests} guests
                  </div>

                  <div className="flex flex-wrap gap-1">
                    {property.features.slice(0, 3).map((feature) => (
                      <Badge key={feature} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                    {property.features.length > 3 && (
                      <Badge variant="outline" className="text-xs">
                        +{property.features.length - 3} more
                      </Badge>
                    )}
                  </div>

                  <div className="flex justify-between items-center pt-2">
                    <div>
                      <span className="text-lg font-bold text-green-600">{property.price}</span>
                      <p className="text-sm text-gray-500">Host: {property.host}</p>
                    </div>
                    <Link href={`/client/property/${property.id}`}>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        View Details
                      </Button>
                    </Link>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredProperties.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No properties found matching your criteria.</p>
            <Button
              variant="outline"
              className="mt-4 bg-transparent"
              onClick={() => {
                setSelectedLocation("")
                setSearchQuery("")
              }}
            >
              Clear Filters
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
