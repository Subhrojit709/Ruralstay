"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Home, ArrowLeft, Calendar, Users, MapPin, Clock, CheckCircle } from "lucide-react"

export default function BookingPage({ params }: { params: { id: string } }) {
  const [bookingStatus, setBookingStatus] = useState<"pending" | "approved" | "rejected">("pending")
  const [paymentStatus, setPaymentStatus] = useState<"pending" | "completed" | "failed">("pending")

  // Mock booking data
  const booking = {
    id: "BK001",
    property: {
      name: "Traditional Kerala Homestay",
      location: "Kerala Backwaters",
      host: "Ravi Kumar",
      hostPhone: "+91 98765 43210",
    },
    checkIn: "2024-02-15",
    checkOut: "2024-02-18",
    guests: 4,
    nights: 3,
    activities: ["Fishing", "Cooking Classes"],
    costs: {
      accommodation: 7500,
      activities: 1300,
      total: 8800,
    },
  }

  const handleApproveBooking = () => {
    setBookingStatus("approved")
  }

  const handlePayment = () => {
    // Simulate payment processing
    setTimeout(() => {
      setPaymentStatus("completed")
    }, 2000)
  }

  const handleCancelBooking = () => {
    // Handle cancellation logic
    alert("Cancellation request sent to host")
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <Link href="/client/dashboard" className="flex items-center space-x-2">
              <ArrowLeft className="h-5 w-5 text-green-600" />
              <Home className="h-8 w-8 text-green-600" />
              <h1 className="text-2xl font-bold text-green-800">Rural Tours</h1>
            </Link>
            <div className="flex items-center space-x-4">
              <Button variant="ghost">My Bookings</Button>
              <Button variant="outline">Logout</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto space-y-6">
          {/* Booking Status */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-green-800">Booking Request</CardTitle>
                  <CardDescription>Booking ID: {booking.id}</CardDescription>
                </div>
                <Badge
                  variant={
                    bookingStatus === "approved"
                      ? "default"
                      : bookingStatus === "rejected"
                        ? "destructive"
                        : "secondary"
                  }
                  className={
                    bookingStatus === "approved" ? "bg-green-600" : bookingStatus === "pending" ? "bg-yellow-600" : ""
                  }
                >
                  {bookingStatus === "pending" && "Pending Approval"}
                  {bookingStatus === "approved" && "Approved"}
                  {bookingStatus === "rejected" && "Rejected"}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              {bookingStatus === "pending" && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-yellow-600 mr-2" />
                    <p className="text-yellow-800">
                      Your booking request has been sent to {booking.property.host}. You'll receive a notification once
                      they respond.
                    </p>
                  </div>
                  {/* Simulate host approval for demo */}
                  <Button className="mt-3 bg-yellow-600 hover:bg-yellow-700" onClick={handleApproveBooking}>
                    Simulate Host Approval
                  </Button>
                </div>
              )}

              {bookingStatus === "approved" && paymentStatus === "pending" && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                    <p className="text-green-800">
                      Great! Your booking has been approved by {booking.property.host}. Please proceed with payment to
                      confirm your reservation.
                    </p>
                  </div>
                </div>
              )}

              {paymentStatus === "completed" && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <CheckCircle className="h-5 w-5 text-green-600 mr-2" />
                    <p className="text-green-800 font-medium">
                      Booking Confirmed! Your payment has been processed successfully.
                    </p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Booking Details */}
          <Card>
            <CardHeader>
              <CardTitle className="text-green-800">Booking Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-gray-800">{booking.property.name}</h4>
                <p className="text-gray-600 flex items-center">
                  <MapPin className="h-4 w-4 mr-1" />
                  {booking.property.location}
                </p>
                <p className="text-sm text-gray-500">Host: {booking.property.host}</p>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-green-600 mr-2" />
                  <div>
                    <p className="font-medium">Check-in</p>
                    <p className="text-sm text-gray-600">{booking.checkIn}</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 text-green-600 mr-2" />
                  <div>
                    <p className="font-medium">Check-out</p>
                    <p className="text-sm text-gray-600">{booking.checkOut}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center">
                <Users className="h-5 w-5 text-green-600 mr-2" />
                <div>
                  <p className="font-medium">{booking.guests} Guests</p>
                  <p className="text-sm text-gray-600">{booking.nights} nights</p>
                </div>
              </div>

              {booking.activities.length > 0 && (
                <div>
                  <p className="font-medium mb-2">Selected Activities</p>
                  <div className="flex flex-wrap gap-2">
                    {booking.activities.map((activity) => (
                      <Badge key={activity} variant="secondary">
                        {activity}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Cost Breakdown */}
          <Card>
            <CardHeader>
              <CardTitle className="text-green-800">Cost Breakdown</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span>Accommodation ({booking.nights} nights)</span>
                <span>₹{booking.costs.accommodation.toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Activities</span>
                <span>₹{booking.costs.activities.toLocaleString()}</span>
              </div>
              <div className="border-t pt-3 flex justify-between font-semibold text-lg">
                <span>Total</span>
                <span className="text-green-600">₹{booking.costs.total.toLocaleString()}</span>
              </div>
            </CardContent>
          </Card>

          {/* Action Buttons */}
          <div className="space-y-3">
            {bookingStatus === "approved" && paymentStatus === "pending" && (
              <Button className="w-full bg-green-600 hover:bg-green-700" size="lg" onClick={handlePayment}>
                Proceed to Payment
              </Button>
            )}

            {paymentStatus === "completed" && (
              <div className="space-y-3">
                <Button className="w-full bg-green-600 hover:bg-green-700" size="lg">
                  Download Booking Confirmation
                </Button>
                <Button variant="outline" className="w-full bg-transparent" size="lg" onClick={handleCancelBooking}>
                  Request Cancellation
                </Button>
              </div>
            )}

            {bookingStatus === "pending" && (
              <Button variant="outline" className="w-full bg-transparent" size="lg">
                Cancel Request
              </Button>
            )}

            <div className="text-center">
              <p className="text-sm text-gray-500">
                Need help? Contact our support team or reach out to your host directly.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
