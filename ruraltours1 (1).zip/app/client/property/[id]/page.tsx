"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Home, MapPin, Users, Star, Heart, CalendarIcon, ArrowLeft } from "lucide-react"
import { format } from "date-fns"

export default function PropertyDetails({ params }: { params: { id: string } }) {
  const [checkIn, setCheckIn] = useState<Date>()
  const [checkOut, setCheckOut] = useState<Date>()
  const [guests, setGuests] = useState(2)
  const [selectedActivities, setSelectedActivities] = useState<string[]>([])

  // Mock property data - in real app, fetch based on params.id
  const property = {
    id: 1,
    name: "Traditional Kerala Homestay",
    location: "Kerala Backwaters",
    host: "Ravi Kumar",
    hostPhone: "+91 98765 43210",
    price: 2500,
    rating: 4.8,
    reviews: 24,
    bedrooms: 3,
    bathrooms: 2,
    maxGuests: 6,
    features: ["WiFi", "Traditional Kitchen", "Backwater View", "Boat Rides", "AC", "Hot Water"],
    activities: [
      { name: "Fishing", price: 500 },
      { name: "Cooking Classes", price: 800 },
      { name: "Village Tours", price: 600 },
      { name: "Ayurveda Massage", price: 1200 },
    ],
    images: [
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
      "/placeholder.svg?height=400&width=600",
    ],
    description:
      "Experience authentic Kerala village life in our traditional homestay located on the serene backwaters. Our family has been welcoming guests for over 10 years, offering genuine hospitality and cultural immersion. Wake up to the sound of birds, enjoy fresh coconut water, and learn traditional cooking methods from our grandmother's recipes.",
    houseRules: [
      "Check-in: 2:00 PM - 8:00 PM",
      "Check-out: 11:00 AM",
      "No smoking inside the house",
      "Pets allowed with prior notice",
      "Quiet hours: 10:00 PM - 7:00 AM",
    ],
  }

  const handleActivityToggle = (activity: string) => {
    setSelectedActivities((prev) =>
      prev.includes(activity) ? prev.filter((a) => a !== activity) : [...prev, activity],
    )
  }

  const calculateTotal = () => {
    const nights = checkIn && checkOut ? Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24)) : 1
    const accommodationCost = property.price * nights
    const activitiesCost = selectedActivities.reduce((total, activityName) => {
      const activity = property.activities.find((a) => a.name === activityName)
      return total + (activity?.price || 0)
    }, 0)
    return accommodationCost + activitiesCost
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <Link href="/client/dashboard" className="flex items-center space-x-2">
              <ArrowLeft className="h-5 w-5 text-green-600" />
              <Home className="h-8 w-8 text-green-600" />
              <h1 className="text-2xl font-bold text-green-800">Rural Tours</h1>
            </Link>
            <div className="flex items-center space-x-4">
              <Button variant="ghost">My Bookings</Button>
              <Button variant="outline">Logout</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Property Details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Image Gallery */}
            <div className="grid grid-cols-2 gap-2">
              <Image
                src={property.images[0] || "/placeholder.svg"}
                alt={property.name}
                width={600}
                height={400}
                className="col-span-2 w-full h-64 object-cover rounded-lg"
              />
              {property.images.slice(1, 4).map((image, index) => (
                <Image
                  key={index}
                  src={image || "/placeholder.svg"}
                  alt={`${property.name} ${index + 2}`}
                  width={300}
                  height={200}
                  className="w-full h-32 object-cover rounded-lg"
                />
              ))}
            </div>

            {/* Property Info */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-2xl text-green-800">{property.name}</CardTitle>
                    <CardDescription className="flex items-center mt-2 text-base">
                      <MapPin className="h-5 w-5 mr-2" />
                      {property.location}
                    </CardDescription>
                  </div>
                  <div className="text-right">
                    <div className="flex items-center">
                      <Star className="h-5 w-5 fill-yellow-400 text-yellow-400 mr-1" />
                      <span className="font-medium text-lg">{property.rating}</span>
                      <span className="text-gray-500 ml-1">({property.reviews} reviews)</span>
                    </div>
                    <Button size="sm" variant="outline" className="mt-2 bg-transparent">
                      <Heart className="h-4 w-4 mr-1" />
                      Save
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center text-gray-600">
                    <Users className="h-5 w-5 mr-2" />
                    {property.bedrooms} bedrooms • {property.bathrooms} bathrooms • Up to {property.maxGuests} guests
                  </div>

                  <p className="text-gray-700 leading-relaxed">{property.description}</p>

                  <div>
                    <h4 className="font-semibold text-green-800 mb-2">Property Features</h4>
                    <div className="flex flex-wrap gap-2">
                      {property.features.map((feature) => (
                        <Badge key={feature} variant="secondary">
                          {feature}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-semibold text-green-800 mb-2">House Rules</h4>
                    <ul className="space-y-1 text-sm text-gray-600">
                      {property.houseRules.map((rule, index) => (
                        <li key={index}>• {rule}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <h4 className="font-semibold text-green-800 mb-2">Your Host</h4>
                    <p className="text-gray-700">
                      <strong>{property.host}</strong> - Local host with 10+ years of experience
                    </p>
                    <p className="text-sm text-gray-600">Contact: {property.hostPhone}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Activities */}
            <Card>
              <CardHeader>
                <CardTitle className="text-green-800">Available Activities</CardTitle>
                <CardDescription>Select activities you'd like to include in your stay</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {property.activities.map((activity) => (
                    <div
                      key={activity.name}
                      className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                        selectedActivities.includes(activity.name)
                          ? "border-green-500 bg-green-50"
                          : "border-gray-200 hover:border-green-300"
                      }`}
                      onClick={() => handleActivityToggle(activity.name)}
                    >
                      <div className="flex justify-between items-center">
                        <h5 className="font-medium">{activity.name}</h5>
                        <span className="text-green-600 font-semibold">₹{activity.price}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Booking Card */}
          <div className="lg:col-span-1">
            <Card className="sticky top-4">
              <CardHeader>
                <CardTitle className="text-green-800">Book Your Stay</CardTitle>
                <div className="text-2xl font-bold text-green-600">
                  ₹{property.price.toLocaleString()}
                  <span className="text-base font-normal text-gray-500">/night</span>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Check-in</label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal bg-transparent">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {checkIn ? format(checkIn, "MMM dd") : "Select date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar mode="single" selected={checkIn} onSelect={setCheckIn} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Check-out</label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button variant="outline" className="w-full justify-start text-left font-normal bg-transparent">
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {checkOut ? format(checkOut, "MMM dd") : "Select date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar mode="single" selected={checkOut} onSelect={setCheckOut} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Guests</label>
                  <select
                    className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                    value={guests}
                    onChange={(e) => setGuests(Number(e.target.value))}
                  >
                    {Array.from({ length: property.maxGuests }, (_, i) => i + 1).map((num) => (
                      <option key={num} value={num}>
                        {num} guest{num > 1 ? "s" : ""}
                      </option>
                    ))}
                  </select>
                </div>

                {selectedActivities.length > 0 && (
                  <div>
                    <h5 className="font-medium text-gray-700 mb-2">Selected Activities</h5>
                    <div className="space-y-1">
                      {selectedActivities.map((activityName) => {
                        const activity = property.activities.find((a) => a.name === activityName)
                        return (
                          <div key={activityName} className="flex justify-between text-sm">
                            <span>{activityName}</span>
                            <span>₹{activity?.price}</span>
                          </div>
                        )
                      })}
                    </div>
                  </div>
                )}

                <div className="border-t pt-4">
                  <div className="flex justify-between items-center text-lg font-semibold">
                    <span>Total</span>
                    <span className="text-green-600">₹{calculateTotal().toLocaleString()}</span>
                  </div>
                </div>

                <Link href={`/client/booking/${property.id}`}>
                  <Button className="w-full bg-green-600 hover:bg-green-700" size="lg">
                    Request to Book
                  </Button>
                </Link>

                <p className="text-xs text-gray-500 text-center">
                  Your booking request will be sent to the host for approval
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
