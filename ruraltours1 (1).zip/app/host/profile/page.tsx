"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Home, ArrowLeft, User, MapPin, Star, Settings, Camera, Edit, Phone, Mail } from "lucide-react"

export default function HostProfile() {
  const [isEditing, setIsEditing] = useState(false)
  const [profileData, setProfileData] = useState({
    name: "Ravi Kumar",
    email: "ravi.kumar@email.com",
    phone: "+91 98765 43210",
    location: "Kerala Backwaters, Kerala",
    bio: "Local host with 10+ years of experience in hospitality. I love sharing the beauty of Kerala's backwaters and traditional culture with guests from around the world. My family has been welcoming travelers for generations.",
    joinDate: "March 2020",
    totalGuests: 247,
    properties: 2,
    languages: ["English", "Hindi", "Malayalam"],
  })

  const hostStats = {
    totalBookings: 89,
    averageRating: 4.8,
    responseRate: 98,
    totalEarnings: 425000,
  }

  const recentReviews = [
    {
      id: 1,
      guest: "Priya Sharma",
      property: "Traditional Kerala Homestay",
      rating: 5,
      comment: "Ravi and his family were incredibly welcoming. The traditional Kerala breakfast was amazing!",
      date: "Feb 2024",
    },
    {
      id: 2,
      guest: "Amit Patel",
      property: "Backwater Villa",
      rating: 5,
      comment: "Perfect location with stunning backwater views. Ravi arranged a wonderful boat tour for us.",
      date: "Jan 2024",
    },
    {
      id: 3,
      guest: "Sarah Johnson",
      property: "Traditional Kerala Homestay",
      rating: 4,
      comment: "Great authentic experience. The cooking class with Ravi's mother was a highlight!",
      date: "Dec 2023",
    },
  ]

  const achievements = [
    { title: "Superhost", description: "Consistently high ratings and great guest experiences", year: "2023" },
    {
      title: "Local Expert",
      description: "Recognized for exceptional local knowledge and recommendations",
      year: "2022",
    },
    { title: "Cultural Ambassador", description: "Outstanding contribution to cultural exchange", year: "2021" },
  ]

  const handleSaveProfile = () => {
    setIsEditing(false)
    // Save profile data logic here
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <Link href="/host/dashboard" className="flex items-center space-x-2">
              <ArrowLeft className="h-5 w-5 text-green-600" />
              <Home className="h-8 w-8 text-green-600" />
              <h1 className="text-2xl font-bold text-green-800">Rural Tours</h1>
            </Link>
            <div className="flex items-center space-x-4">
              <Button variant="ghost">Dashboard</Button>
              <Button variant="outline">Logout</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          {/* Profile Header */}
          <Card className="mb-8">
            <CardContent className="p-8">
              <div className="flex items-start space-x-6">
                <div className="relative">
                  <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center">
                    <User className="h-12 w-12 text-green-600" />
                  </div>
                  <Button
                    size="sm"
                    className="absolute -bottom-2 -right-2 rounded-full p-2 bg-green-600 hover:bg-green-700"
                  >
                    <Camera className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h2 className="text-2xl font-bold text-green-800">{profileData.name}</h2>
                      <p className="text-gray-600 flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {profileData.location}
                      </p>
                      <div className="flex items-center space-x-4 mt-2">
                        <Badge className="bg-green-600">Superhost</Badge>
                        <div className="flex items-center">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                          <span className="font-medium">{hostStats.averageRating}</span>
                        </div>
                      </div>
                    </div>
                    <Button variant="outline" onClick={() => setIsEditing(!isEditing)} className="bg-transparent">
                      <Edit className="h-4 w-4 mr-2" />
                      {isEditing ? "Cancel" : "Edit Profile"}
                    </Button>
                  </div>
                  <p className="text-gray-700 mb-4">{profileData.bio}</p>
                  <div className="grid grid-cols-4 gap-4">
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-600">{profileData.totalGuests}</p>
                      <p className="text-sm text-gray-600">Total Guests</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-600">{hostStats.totalBookings}</p>
                      <p className="text-sm text-gray-600">Bookings</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-600">{hostStats.responseRate}%</p>
                      <p className="text-sm text-gray-600">Response Rate</p>
                    </div>
                    <div className="text-center">
                      <p className="text-2xl font-bold text-green-600">{profileData.properties}</p>
                      <p className="text-sm text-gray-600">Properties</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Profile Tabs */}
          <Tabs defaultValue="reviews" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
              <TabsTrigger value="achievements">Achievements</TabsTrigger>
              <TabsTrigger value="verification">Verification</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="reviews">
              <Card>
                <CardHeader>
                  <CardTitle className="text-green-800">Guest Reviews</CardTitle>
                  <CardDescription>What guests are saying about your hospitality</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentReviews.map((review) => (
                      <div key={review.id} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div>
                            <h4 className="font-semibold text-green-800">{review.guest}</h4>
                            <p className="text-sm text-gray-600">{review.property}</p>
                          </div>
                          <div className="text-right">
                            <div className="flex items-center">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-4 w-4 ${
                                    i < review.rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                                  }`}
                                />
                              ))}
                            </div>
                            <p className="text-xs text-gray-500">{review.date}</p>
                          </div>
                        </div>
                        <p className="text-gray-700 text-sm">"{review.comment}"</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="achievements">
              <Card>
                <CardHeader>
                  <CardTitle className="text-green-800">Achievements & Recognition</CardTitle>
                  <CardDescription>Your hosting milestones and awards</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {achievements.map((achievement, index) => (
                      <div key={index} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                          <Star className="h-6 w-6 text-green-600" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold text-green-800">{achievement.title}</h4>
                          <p className="text-gray-600 text-sm">{achievement.description}</p>
                        </div>
                        <Badge variant="secondary">{achievement.year}</Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="verification">
              <Card>
                <CardHeader>
                  <CardTitle className="text-green-800">Verification Status</CardTitle>
                  <CardDescription>Your identity and property verification details</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <User className="h-4 w-4 text-green-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">Identity Verification</h4>
                          <p className="text-sm text-gray-600">Government ID verified</p>
                        </div>
                      </div>
                      <Badge className="bg-green-600">Verified</Badge>
                    </div>

                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <Phone className="h-4 w-4 text-green-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">Phone Number</h4>
                          <p className="text-sm text-gray-600">{profileData.phone}</p>
                        </div>
                      </div>
                      <Badge className="bg-green-600">Verified</Badge>
                    </div>

                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <Mail className="h-4 w-4 text-green-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">Email Address</h4>
                          <p className="text-sm text-gray-600">{profileData.email}</p>
                        </div>
                      </div>
                      <Badge className="bg-green-600">Verified</Badge>
                    </div>

                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center">
                          <Home className="h-4 w-4 text-green-600" />
                        </div>
                        <div>
                          <h4 className="font-medium">Property Verification</h4>
                          <p className="text-sm text-gray-600">All properties verified by our team</p>
                        </div>
                      </div>
                      <Badge className="bg-green-600">Verified</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle className="text-green-800">Profile Settings</CardTitle>
                  <CardDescription>Manage your host account information</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {isEditing ? (
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                        <Input
                          value={profileData.name}
                          onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                        <Input
                          value={profileData.email}
                          onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                        <Input
                          value={profileData.phone}
                          onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
                        <Input
                          value={profileData.location}
                          onChange={(e) => setProfileData({ ...profileData, location: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
                        <textarea
                          className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                          rows={4}
                          value={profileData.bio}
                          onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                        />
                      </div>
                      <div className="flex space-x-3">
                        <Button className="bg-green-600 hover:bg-green-700" onClick={handleSaveProfile}>
                          Save Changes
                        </Button>
                        <Button variant="outline" onClick={() => setIsEditing(false)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                          <p className="text-gray-900">{profileData.email}</p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                          <p className="text-gray-900">{profileData.phone}</p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Host Since</label>
                          <p className="text-gray-900">{profileData.joinDate}</p>
                        </div>
                        <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Languages</label>
                          <p className="text-gray-900">{profileData.languages.join(", ")}</p>
                        </div>
                      </div>

                      <div className="pt-4 border-t">
                        <h4 className="font-medium text-gray-900 mb-3">Hosting Preferences</h4>
                        <div className="space-y-3">
                          <label className="flex items-center">
                            <input type="checkbox" className="mr-3" defaultChecked />
                            <span className="text-sm">Allow instant bookings</span>
                          </label>
                          <label className="flex items-center">
                            <input type="checkbox" className="mr-3" defaultChecked />
                            <span className="text-sm">Send booking notifications via SMS</span>
                          </label>
                          <label className="flex items-center">
                            <input type="checkbox" className="mr-3" />
                            <span className="text-sm">Allow pets in properties</span>
                          </label>
                        </div>
                      </div>

                      <div className="pt-4 border-t">
                        <h4 className="font-medium text-gray-900 mb-3">Account Actions</h4>
                        <div className="space-y-2">
                          <Button variant="outline" className="w-full justify-start bg-transparent">
                            <Settings className="h-4 w-4 mr-2" />
                            Change Password
                          </Button>
                          <Button variant="outline" className="w-full justify-start bg-transparent">
                            Download Host Data
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
