"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Home, Plus, Calendar, Users, Star, MapPin, Bell, Settings, User } from "lucide-react"

export default function HostDashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  // Mock data for host dashboard
  const hostData = {
    name: "Ravi Kumar",
    properties: 2,
    totalBookings: 47,
    rating: 4.8,
    earnings: 125000,
  }

  const bookingRequests = [
    {
      id: 1,
      guestName: "Priya Sharma",
      property: "Traditional Kerala Homestay",
      checkIn: "2024-02-15",
      checkOut: "2024-02-18",
      guests: 4,
      status: "pending",
      amount: 8800,
    },
    {
      id: 2,
      guestName: "Amit Patel",
      property: "Backwater Villa",
      checkIn: "2024-02-20",
      checkOut: "2024-02-23",
      guests: 2,
      status: "pending",
      amount: 6500,
    },
  ]

  const properties = [
    {
      id: 1,
      name: "Traditional Kerala Homestay",
      location: "Kerala Backwaters",
      price: 2500,
      rating: 4.8,
      reviews: 24,
      bookings: 18,
      status: "active",
      image: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 2,
      name: "Backwater Villa",
      location: "Kerala Backwaters",
      price: 3200,
      rating: 4.9,
      reviews: 12,
      bookings: 8,
      status: "active",
      image: "/placeholder.svg?height=200&width=300",
    },
  ]

  const handleBookingAction = (bookingId: number, action: "approve" | "reject") => {
    // Handle booking approval/rejection
    console.log(`${action} booking ${bookingId}`)
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <Link href="/" className="flex items-center space-x-2">
              <Home className="h-8 w-8 text-green-600" />
              <h1 className="text-2xl font-bold text-green-800">Rural Tours</h1>
            </Link>
            <div className="flex items-center space-x-4">
              <Button variant="ghost" className="relative">
                <Bell className="h-5 w-5" />
                <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 flex items-center justify-center text-xs bg-red-500">
                  2
                </Badge>
              </Button>
              <Link href="/host/profile">
                <Button variant="ghost">
                  <User className="h-5 w-5 mr-2" />
                  Profile
                </Button>
              </Link>
              <Button variant="ghost">
                <Settings className="h-5 w-5 mr-2" />
                Settings
              </Button>
              <Button variant="outline">Logout</Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-green-800 mb-2">Welcome back, {hostData.name}!</h2>
          <p className="text-gray-600">Manage your properties and bookings from your dashboard</p>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Properties</p>
                  <p className="text-2xl font-bold text-green-600">{hostData.properties}</p>
                </div>
                <Home className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Bookings</p>
                  <p className="text-2xl font-bold text-green-600">{hostData.totalBookings}</p>
                </div>
                <Calendar className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Average Rating</p>
                  <p className="text-2xl font-bold text-green-600">{hostData.rating}</p>
                </div>
                <Star className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Earnings</p>
                  <p className="text-2xl font-bold text-green-600">₹{hostData.earnings.toLocaleString()}</p>
                </div>
                <Users className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Navigation Tabs */}
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg mb-6 w-fit">
          <button
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === "overview" ? "bg-white text-green-600 shadow-sm" : "text-gray-600 hover:text-gray-800"
            }`}
            onClick={() => setActiveTab("overview")}
          >
            Overview
          </button>
          <button
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === "requests" ? "bg-white text-green-600 shadow-sm" : "text-gray-600 hover:text-gray-800"
            }`}
            onClick={() => setActiveTab("requests")}
          >
            Booking Requests
          </button>
          <button
            className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
              activeTab === "properties" ? "bg-white text-green-600 shadow-sm" : "text-gray-600 hover:text-gray-800"
            }`}
            onClick={() => setActiveTab("properties")}
          >
            My Properties
          </button>
        </div>

        {/* Content based on active tab */}
        {activeTab === "overview" && (
          <div className="space-y-6">
            {/* Recent Booking Requests */}
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-green-800">Recent Booking Requests</CardTitle>
                  <Button variant="outline" size="sm" onClick={() => setActiveTab("requests")}>
                    View All
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {bookingRequests.slice(0, 2).map((request) => (
                  <div
                    key={request.id}
                    className="flex items-center justify-between p-4 border rounded-lg mb-3 last:mb-0"
                  >
                    <div>
                      <h4 className="font-medium">{request.guestName}</h4>
                      <p className="text-sm text-gray-600">{request.property}</p>
                      <p className="text-sm text-gray-500">
                        {request.checkIn} - {request.checkOut} • {request.guests} guests
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-green-600">₹{request.amount.toLocaleString()}</p>
                      <div className="flex space-x-2 mt-2">
                        <Button
                          size="sm"
                          className="bg-green-600 hover:bg-green-700"
                          onClick={() => handleBookingAction(request.id, "approve")}
                        >
                          Approve
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleBookingAction(request.id, "reject")}>
                          Decline
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Property Performance */}
            <Card>
              <CardHeader>
                <CardTitle className="text-green-800">Property Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {properties.map((property) => (
                    <div key={property.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <Image
                          src={property.image || "/placeholder.svg"}
                          alt={property.name}
                          width={80}
                          height={60}
                          className="rounded-lg object-cover"
                        />
                        <div>
                          <h4 className="font-medium">{property.name}</h4>
                          <p className="text-sm text-gray-600 flex items-center">
                            <MapPin className="h-4 w-4 mr-1" />
                            {property.location}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center mb-1">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                          <span className="font-medium">{property.rating}</span>
                          <span className="text-gray-500 text-sm ml-1">({property.reviews})</span>
                        </div>
                        <p className="text-sm text-gray-600">{property.bookings} bookings</p>
                        <p className="font-semibold text-green-600">₹{property.price}/night</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "requests" && (
          <Card>
            <CardHeader>
              <CardTitle className="text-green-800">Booking Requests</CardTitle>
              <CardDescription>Review and respond to guest booking requests</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {bookingRequests.map((request) => (
                  <div key={request.id} className="p-6 border rounded-lg">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h4 className="text-lg font-medium">{request.guestName}</h4>
                        <p className="text-gray-600">{request.property}</p>
                        <Badge variant="secondary" className="mt-1">
                          {request.status}
                        </Badge>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-green-600">₹{request.amount.toLocaleString()}</p>
                        <p className="text-sm text-gray-500">Total amount</p>
                      </div>
                    </div>

                    <div className="grid md:grid-cols-3 gap-4 mb-4">
                      <div>
                        <p className="text-sm font-medium text-gray-700">Check-in</p>
                        <p className="text-gray-600">{request.checkIn}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-700">Check-out</p>
                        <p className="text-gray-600">{request.checkOut}</p>
                      </div>
                      <div>
                        <p className="text-sm font-medium text-gray-700">Guests</p>
                        <p className="text-gray-600">{request.guests} guests</p>
                      </div>
                    </div>

                    <div className="flex space-x-3">
                      <Button
                        className="bg-green-600 hover:bg-green-700"
                        onClick={() => handleBookingAction(request.id, "approve")}
                      >
                        Approve Booking
                      </Button>
                      <Button variant="outline" onClick={() => handleBookingAction(request.id, "reject")}>
                        Decline
                      </Button>
                      <Button variant="ghost">Contact Guest</Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {activeTab === "properties" && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-xl font-semibold text-green-800">My Properties</h3>
              <Button className="bg-green-600 hover:bg-green-700">
                <Plus className="h-4 w-4 mr-2" />
                Add New Property
              </Button>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              {properties.map((property) => (
                <Card key={property.id}>
                  <div className="relative">
                    <Image
                      src={property.image || "/placeholder.svg"}
                      alt={property.name}
                      width={400}
                      height={200}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                    <Badge
                      className={`absolute top-2 right-2 ${
                        property.status === "active" ? "bg-green-600" : "bg-gray-600"
                      }`}
                    >
                      {property.status}
                    </Badge>
                  </div>

                  <CardHeader>
                    <CardTitle className="text-green-800">{property.name}</CardTitle>
                    <CardDescription className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {property.location}
                    </CardDescription>
                  </CardHeader>

                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400 mr-1" />
                          <span className="font-medium">{property.rating}</span>
                          <span className="text-gray-500 text-sm ml-1">({property.reviews} reviews)</span>
                        </div>
                        <span className="font-semibold text-green-600">₹{property.price}/night</span>
                      </div>

                      <p className="text-sm text-gray-600">{property.bookings} total bookings</p>

                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                          Edit Property
                        </Button>
                        <Button size="sm" variant="outline" className="flex-1 bg-transparent">
                          View Analytics
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
