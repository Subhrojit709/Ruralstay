"use client"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Home, Users, Building } from "lucide-react"

export default function SignupPage() {
  const searchParams = useSearchParams()
  const initialType = searchParams.get("type") || ""
  const [userType, setUserType] = useState<"host" | "client" | "">(initialType as "host" | "client" | "")

  if (!userType) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-green-50 to-green-100 flex items-center justify-center p-4">
        <div className="w-full max-w-4xl">
          <div className="text-center mb-8">
            <Link href="/" className="flex items-center justify-center space-x-2 mb-6">
              <Home className="h-8 w-8 text-green-600" />
              <h1 className="text-2xl font-bold text-green-800">Rural Tours</h1>
            </Link>
            <h2 className="text-3xl font-bold text-green-800 mb-4">Join Rural Tours</h2>
            <p className="text-green-700">Choose how you'd like to get started</p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-green-300"
              onClick={() => setUserType("client")}
            >
              <CardHeader className="text-center">
                <Users className="h-16 w-16 text-green-600 mx-auto mb-4" />
                <CardTitle className="text-2xl text-green-800">I'm a Traveler</CardTitle>
                <CardDescription className="text-lg">
                  Looking for authentic rural experiences and unique stays
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• Browse rural properties</li>
                  <li>• Book unique experiences</li>
                  <li>• Connect with local hosts</li>
                  <li>• Enjoy cultural activities</li>
                </ul>
                <Button className="w-full mt-4 bg-green-600 hover:bg-green-700">Sign Up as Traveler</Button>
              </CardContent>
            </Card>

            <Card
              className="cursor-pointer hover:shadow-lg transition-shadow border-2 hover:border-green-300"
              onClick={() => setUserType("host")}
            >
              <CardHeader className="text-center">
                <Building className="h-16 w-16 text-green-600 mx-auto mb-4" />
                <CardTitle className="text-2xl text-green-800">I'm a Host</CardTitle>
                <CardDescription className="text-lg">Want to share my rural property and local culture</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2 text-sm text-gray-600">
                  <li>• List your property</li>
                  <li>• Set your own prices</li>
                  <li>• Meet travelers from around the world</li>
                  <li>• Earn extra income</li>
                </ul>
                <Button className="w-full mt-4 bg-green-600 hover:bg-green-700">Sign Up as Host</Button>
              </CardContent>
            </Card>
          </div>

          <div className="text-center mt-8">
            <p className="text-gray-600">
              Already have an account?{" "}
              <Link href="/login" className="text-green-600 hover:underline font-medium">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    )
  }

  if (userType === "host") {
    return <HostSignup />
  }

  return <ClientSignup />
}

function HostSignup() {
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    name: "",
    address: "",
    phone: "",
    email: "",
    identityType: "",
    identityNumber: "",
    otpVerified: false,
  })

  const handleNext = () => {
    setStep(step + 1)
  }

  const handleBack = () => {
    setStep(step - 1)
  }

  if (step === 1) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-green-50 to-green-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <Link href="/" className="flex items-center justify-center space-x-2 mb-4">
              <Home className="h-6 w-6 text-green-600" />
              <span className="text-xl font-bold text-green-800">Rural Tours</span>
            </Link>
            <CardTitle className="text-2xl text-green-800">Host Registration</CardTitle>
            <CardDescription>Step 1 of 2: Personal Information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
              <input
                type="text"
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter your full name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Address</label>
              <textarea
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter your complete address"
                rows={3}
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
              <div className="flex space-x-2">
                <input
                  type="tel"
                  className="flex-1 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Enter phone number"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                />
                <Button variant="outline" className="px-4 bg-transparent">
                  Send OTP
                </Button>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
              <input
                type="email"
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter your email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Identity Proof</label>
              <select
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                value={formData.identityType}
                onChange={(e) => setFormData({ ...formData, identityType: e.target.value })}
              >
                <option value="">Select ID Type</option>
                <option value="aadhar">Aadhar Card</option>
                <option value="pan">PAN Card</option>
              </select>
            </div>
            <div>
              <input
                type="text"
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter ID number"
                value={formData.identityNumber}
                onChange={(e) => setFormData({ ...formData, identityNumber: e.target.value })}
              />
            </div>
            <Button className="w-full bg-green-600 hover:bg-green-700" onClick={handleNext}>
              Continue to Property Details
            </Button>
            <div className="text-center">
              <Link href="/login" className="text-sm text-green-600 hover:underline">
                Already have an account? Sign in
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return <HostPropertyDetails onBack={handleBack} />
}

function HostPropertyDetails({ onBack }: { onBack: () => void }) {
  const [propertyData, setPropertyData] = useState({
    bedrooms: "",
    bathrooms: "",
    maxGuests: "",
    rent: "",
    features: "",
    activities: "",
    packageDetails: "",
  })

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-green-100 p-4">
      <div className="max-w-2xl mx-auto">
        <Card>
          <CardHeader className="text-center">
            <Link href="/" className="flex items-center justify-center space-x-2 mb-4">
              <Home className="h-6 w-6 text-green-600" />
              <span className="text-xl font-bold text-green-800">Rural Tours</span>
            </Link>
            <CardTitle className="text-2xl text-green-800">Property Details</CardTitle>
            <CardDescription>Step 2 of 2: Tell us about your property</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Property Photos</label>
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <p className="text-gray-500">Upload photos of your property, interior, and surroundings</p>
                <Button variant="outline" className="mt-2 bg-transparent">
                  Choose Files
                </Button>
              </div>
            </div>

            <div className="grid md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bedrooms</label>
                <input
                  type="number"
                  className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Number of bedrooms"
                  value={propertyData.bedrooms}
                  onChange={(e) => setPropertyData({ ...propertyData, bedrooms: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Bathrooms</label>
                <input
                  type="number"
                  className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Number of bathrooms"
                  value={propertyData.bathrooms}
                  onChange={(e) => setPropertyData({ ...propertyData, bathrooms: e.target.value })}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Max Guests</label>
                <input
                  type="number"
                  className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  placeholder="Maximum guests"
                  value={propertyData.maxGuests}
                  onChange={(e) => setPropertyData({ ...propertyData, maxGuests: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Property Features</label>
              <textarea
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Describe your property features (WiFi, AC, Kitchen, etc.)"
                rows={3}
                value={propertyData.features}
                onChange={(e) => setPropertyData({ ...propertyData, features: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Available Activities</label>
              <textarea
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="List fun activities available (farming, cooking, trekking, etc.)"
                rows={3}
                value={propertyData.activities}
                onChange={(e) => setPropertyData({ ...propertyData, activities: e.target.value })}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Vacation Package & Rent</label>
              <textarea
                className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Describe your vacation packages and pricing details"
                rows={4}
                value={propertyData.packageDetails}
                onChange={(e) => setPropertyData({ ...propertyData, packageDetails: e.target.value })}
              />
            </div>

            <div className="flex space-x-4">
              <Button variant="outline" onClick={onBack} className="flex-1 bg-transparent">
                Back
              </Button>
              <Link href="/host/profile" className="flex-1">
                <Button className="w-full bg-green-600 hover:bg-green-700">Complete Registration</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

function ClientSignup() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-green-100 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <Link href="/" className="flex items-center justify-center space-x-2 mb-4">
            <Home className="h-6 w-6 text-green-600" />
            <span className="text-xl font-bold text-green-800">Rural Tours</span>
          </Link>
          <CardTitle className="text-2xl text-green-800">Traveler Registration</CardTitle>
          <CardDescription>Create your account to start exploring</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
            <input
              type="text"
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="Enter your full name"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
            <div className="flex space-x-2">
              <input
                type="tel"
                className="flex-1 p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
                placeholder="Enter phone number"
              />
              <Button variant="outline" className="px-4 bg-transparent">
                Send OTP
              </Button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
            <input
              type="email"
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="Enter your email"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
            <input
              type="password"
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-green-500 focus:border-transparent"
              placeholder="Create a password"
            />
          </div>
          <Link href="/client/profile">
            <Button className="w-full bg-green-600 hover:bg-green-700">Create Account</Button>
          </Link>
          <div className="text-center">
            <Link href="/login" className="text-sm text-green-600 hover:underline">
              Already have an account? Sign in
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
