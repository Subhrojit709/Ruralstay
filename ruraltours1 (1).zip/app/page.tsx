import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { MapPin, Home, Users, Star } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-green-100">
      {/* Header */}
      <header className="bg-white shadow-sm">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <Home className="h-8 w-8 text-green-600" />
            <h1 className="text-2xl font-bold text-green-800">Rural Tours</h1>
          </div>
          <div className="space-x-4">
            <Link href="/login">
              <Button variant="outline">Login</Button>
            </Link>
            <Link href="/signup">
              <Button className="bg-green-600 hover:bg-green-700">Sign Up</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 text-center">
        <div className="container mx-auto px-4">
          <h2 className="text-5xl font-bold text-green-800 mb-6">Discover Authentic Rural Experiences</h2>
          <p className="text-xl text-green-700 mb-8 max-w-2xl mx-auto">
            Connect with local hosts and experience the beauty of rural life. Stay in traditional homes, enjoy local
            cuisine, and create unforgettable memories.
          </p>
          <div className="flex justify-center space-x-4">
            <Link href="/signup?type=client">
              <Button size="lg" className="bg-green-600 hover:bg-green-700">
                Find Your Stay
              </Button>
            </Link>
            <Link href="/signup?type=host">
              <Button
                size="lg"
                variant="outline"
                className="border-green-600 text-green-600 hover:bg-green-50 bg-transparent"
              >
                Become a Host
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h3 className="text-3xl font-bold text-center text-green-800 mb-12">Why Choose Rural Tours?</h3>
          <div className="grid md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardHeader>
                <MapPin className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <CardTitle className="text-green-800">Authentic Locations</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Discover hidden gems in rural villages with rich cultural heritage and natural beauty.
                </CardDescription>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <Users className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <CardTitle className="text-green-800">Local Hosts</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Stay with verified local families who provide genuine hospitality and cultural insights.
                </CardDescription>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardHeader>
                <Star className="h-12 w-12 text-green-600 mx-auto mb-4" />
                <CardTitle className="text-green-800">Unique Experiences</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription>
                  Enjoy traditional activities, local cuisine, and immersive cultural experiences.
                </CardDescription>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-green-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h3 className="text-3xl font-bold mb-6">Ready to Start Your Rural Adventure?</h3>
          <p className="text-xl mb-8 opacity-90">
            Join thousands of travelers and hosts creating meaningful connections.
          </p>
          <Link href="/signup">
            <Button size="lg" variant="secondary" className="bg-white text-green-600 hover:bg-gray-100">
              Get Started Today
            </Button>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-800 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <Home className="h-6 w-6" />
            <span className="text-xl font-bold">Rural Tours</span>
          </div>
          <p className="opacity-80">Connecting travelers with authentic rural experiences</p>
        </div>
      </footer>
    </div>
  )
}
